'''
Importing module timesTable.py and use its function from this program
'''
import timesTable

#Call the function of the imported module
timesTable.doTimes(3)