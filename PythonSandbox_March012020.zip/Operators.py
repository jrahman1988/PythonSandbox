# Different types of operators (Relational, Arithmetic and Logical)

# Arithmetic operator #
a=10
b=30

#addition
print("Addition operator a + b ", a + b)

#substraction
print("Sustraction operator a - b ", a - b)

#multiplication
print("Multiplication operator a * b ", a * b)

#division
print("Division operator a / b ", a / b)


# Relational operator #
x=100
y=200

#greater than >
print("Is x greater than y, x > y ?", x > y)

#smaller than <
print("Is x smaller than y, x < y ?", x < y)

#equal  ==
print("Is x equal to y, x == y ?", x == y)

#not equal !=
print("Is x not equal to y, x != y ?", x != y)


# Logical operator #
x=100
y=200
a=5
b=10

#& (AND) operator
print("The logical operation of (100 > 200) & (5 > 10) is ", (a > b) & (x > y))

#| (OR) operator
print("The logical operation of (100 < 200) | (5 > 10) is ", (a < b) | (x > y))