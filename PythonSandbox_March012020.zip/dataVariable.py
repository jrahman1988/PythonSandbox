# Different data types
import math

var1 = 100
var2 = 100.99
var3 = True
var4 = 5+4j

print("Type of var1 = ", type(var1))
print("Type of var2 = ", type(var2))
print("Type of var3 = ", type(var3))
print("Type of var4 = ", type(var4))
