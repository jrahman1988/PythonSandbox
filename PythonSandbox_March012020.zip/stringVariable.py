# String variables
var1 = "Bob"
var2 = 'Matt'
var3 = "John"

print(var1, var2, var3)

print("Type of variable var1 = ", type(var1))
