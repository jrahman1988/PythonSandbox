print("Hello World")
print (3*4)